import joblib
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
from sklearn.model_selection import train_test_split

# Load the data
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
train = train.drop(['employee_id', 'region', 'recruitment_channel'], axis=1)
test = test.drop(['employee_id', 'region', 'recruitment_channel'], axis=1)

# Label encoding with OneHotEncoder
categorical_features = ['department', 'education', 'gender']
ct = ColumnTransformer([('encoder', OneHotEncoder(), categorical_features)], remainder='passthrough')

# Splitting the data
X = train.drop('is_promoted', axis=1)
y = train['is_promoted']

# Transform the features
X = ct.fit_transform(X)
test = ct.transform(test)

# Splitting the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Scaling the data
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

# Train the model
dt = DecisionTreeClassifier()
dt.fit(X_train, y_train)

# Save the model and transformers
joblib.dump(dt, 'decision_tree_model.pkl')
joblib.dump(ct, 'column_transformer.pkl')
joblib.dump(sc, 'scaler.pkl')

print("Model and transformers have been saved.")
