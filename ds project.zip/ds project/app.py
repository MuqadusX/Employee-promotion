from flask import Flask, request, render_template, flash
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.tree import DecisionTreeClassifier
import joblib

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Load the model and transformers
dt = joblib.load('decision_tree_model.pkl')
ct = joblib.load('column_transformer.pkl')
sc = joblib.load('scaler.pkl')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/single_prediction', methods=['GET', 'POST'])
def single_prediction():
    if request.method == 'POST':
        data = {
            'department': [request.form['department']],
            'education': [request.form['education']],
            'gender': [request.form['gender']],
            'no_of_trainings': [request.form['no_of_trainings']],
            'age': [request.form['age']],
            'previous_year_rating': [request.form['previous_year_rating']],
            'length_of_service': [request.form['length_of_service']],
            'awards_won?': [request.form['awards_won?']],
            'avg_training_score': [request.form['avg_training_score']]
        }
        data_df = pd.DataFrame(data)
        
        # Transform the input data
        data_transformed = ct.transform(data_df)
        data_scaled = sc.transform(data_transformed)
        
        prediction = dt.predict(data_scaled)
        result = 'Promoted' if prediction[0] == 1 else 'Not Promoted'
        
        flash(f"Employee Promotion Prediction: {result}")
    
    return render_template('single_prediction.html')

@app.route('/batch_prediction', methods=['GET', 'POST'])
def batch_prediction():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            df = pd.read_csv(file)
            df = df.drop(['employee_id', 'region', 'recruitment_channel'], axis=1)
            
            # Transform the input data
            df_transformed = ct.transform(df)
            df_scaled = sc.transform(df_transformed)
            predictions = dt.predict(df_scaled)
            
            df['is_promoted'] = predictions
            output_path = 'predictions.csv'
            df.to_csv(output_path, index=False)
            flash(f"Predictions saved to {output_path}")
    
    return render_template('batch_prediction.html')

if __name__ == '__main__':
    app.run(debug=True)
